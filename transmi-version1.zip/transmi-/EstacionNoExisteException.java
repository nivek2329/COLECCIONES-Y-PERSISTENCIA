public class EstacionNoExisteException extends Exception {
    private final String nombreEstacion;
    
    public EstacionNoExisteException(String nombreEstacion) {
        super("La estación '" + nombreEstacion + "' no existe en el sistema.");
        this.nombreEstacion = nombreEstacion;
    }
    
    public String getNombreEstacion() {
        return nombreEstacion;
    }
}
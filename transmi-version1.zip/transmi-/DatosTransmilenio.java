import java.util.*;

/**
 * Clase que contiene TODAS las estaciones de Transmilenio
 * 
 * @author POOB Team
 * @version 2.0
 */
public class DatosTransmilenio {
    
    private SistemaTransmilenio sistema;
    
    public DatosTransmilenio() {
        sistema = SistemaTransmilenio.getInstance();
    }
    
    /**
     * Carga todas las troncales con sus estaciones
     */
    public void cargarTodasLasTroncales() {
        System.out.println("=== CARGANDO SISTEMA TRANSMILENIO ===\n");
        
        // ===== 1. TRONCAL PORTAL NORTE =====
        Troncal norte = new Troncal("B", "Portal Norte", 500);
        agregarEstacionATroncal(norte, "Terminal", Ocupacion.ALTO, 0);
        agregarEstacionATroncal(norte, "Calle 187", Ocupacion.MEDIO, 450);
        agregarEstacionATroncal(norte, "Calle 161", Ocupacion.MEDIO, 520);
        agregarEstacionATroncal(norte, "Mazurén", Ocupacion.ALTO, 480);
        agregarEstacionATroncal(norte, "Calle 146", Ocupacion.MEDIO, 500);
        agregarEstacionATroncal(norte, "Calle 142", Ocupacion.BAJO, 350);
        agregarEstacionATroncal(norte, "Alcalá", Ocupacion.MEDIO, 400);
        agregarEstacionATroncal(norte, "Prado", Ocupacion.BAJO, 380);
        agregarEstacionATroncal(norte, "Calle 127", Ocupacion.ALTO, 420);
        agregarEstacionATroncal(norte, "Pepe Sierra", Ocupacion.MEDIO, 450);
        agregarEstacionATroncal(norte, "Calle 106", Ocupacion.MEDIO, 480);
        agregarEstacionATroncal(norte, "Calle 100", Ocupacion.ALTO, 400);
        agregarEstacionATroncal(norte, "Virrey", Ocupacion.MEDIO, 350);
        agregarEstacionATroncal(norte, "Calle 85", Ocupacion.MEDIO, 380);
        agregarEstacionATroncal(norte, "Héroes", Ocupacion.ALTO, 420);
        sistema.agregarTroncal(norte);
        
        // ===== 2. TRONCAL SUBA (C) =====
        Troncal suba = new Troncal("C", "Suba", 480);
        agregarEstacionATroncal(suba, "Portal Suba", Ocupacion.ALTO, 0);
        agregarEstacionATroncal(suba, "La Campiña", Ocupacion.MEDIO, 500);
        agregarEstacionATroncal(suba, "Transversal 91", Ocupacion.MEDIO, 450);
        agregarEstacionATroncal(suba, "21 Ángeles", Ocupacion.ALTO, 480);
        agregarEstacionATroncal(suba, "Humedal Córdoba", Ocupacion.BAJO, 400);
        agregarEstacionATroncal(suba, "Niza Calle 127", Ocupacion.MEDIO, 520);
        agregarEstacionATroncal(suba, "Gratamira", Ocupacion.MEDIO, 380);
        agregarEstacionATroncal(suba, "Suba Av. Boyacá", Ocupacion.ALTO, 450);
        agregarEstacionATroncal(suba, "Suba Calle 100", Ocupacion.MEDIO, 420);
        agregarEstacionATroncal(suba, "Suba Calle 95", Ocupacion.BAJO, 350);
        agregarEstacionATroncal(suba, "Rionegro", Ocupacion.MEDIO, 400);
        agregarEstacionATroncal(suba, "San Martín", Ocupacion.MEDIO, 380);
        sistema.agregarTroncal(suba);
        
        // ===== 3. TRONCAL CALLE 80 (D) =====
        Troncal calle80 = new Troncal("D", "Calle 80", 520);
        agregarEstacionATroncal(calle80, "Portal 80", Ocupacion.ALTO, 0);
        agregarEstacionATroncal(calle80, "Quirigua", Ocupacion.MEDIO, 550);
        agregarEstacionATroncal(calle80, "Minuto de Dios", Ocupacion.ALTO, 480);
        agregarEstacionATroncal(calle80, "Carrera 53", Ocupacion.MEDIO, 420);
        agregarEstacionATroncal(calle80, "Ferias", Ocupacion.MEDIO, 450);
        agregarEstacionATroncal(calle80, "Avenida 68", Ocupacion.ALTO, 500);
        agregarEstacionATroncal(calle80, "Carrera 47", Ocupacion.BAJO, 380);
        agregarEstacionATroncal(calle80, "Escuela Militar", Ocupacion.BAJO, 400);
        agregarEstacionATroncal(calle80, "Polo", Ocupacion.MEDIO, 350);
        sistema.agregarTroncal(calle80);
        
        // ===== 4. TRONCAL CARACAS (A/H) =====
        Troncal caracas = new Troncal("A", "Caracas", 450);
        agregarEstacionATroncal(caracas, "Portal Usme", Ocupacion.ALTO, 0);
        agregarEstacionATroncal(caracas, "Portal Tunal", Ocupacion.ALTO, 800);
        agregarEstacionATroncal(caracas, "Molinos", Ocupacion.MEDIO, 450);
        agregarEstacionATroncal(caracas, "Consuelo", Ocupacion.MEDIO, 400);
        agregarEstacionATroncal(caracas, "Socorro", Ocupacion.BAJO, 380);
        agregarEstacionATroncal(caracas, "Santa Lucía", Ocupacion.MEDIO, 420);
        agregarEstacionATroncal(caracas, "Biblioteca", Ocupacion.BAJO, 350);
        agregarEstacionATroncal(caracas, "Parque", Ocupacion.MEDIO, 400);
        agregarEstacionATroncal(caracas, "Calle 40 Sur", Ocupacion.ALTO, 450);
        agregarEstacionATroncal(caracas, "Sena", Ocupacion.MEDIO, 380);
        agregarEstacionATroncal(caracas, "Restrepo", Ocupacion.ALTO, 420);
        agregarEstacionATroncal(caracas, "Olaya", Ocupacion.MEDIO, 400);
        agregarEstacionATroncal(caracas, "Quiroga", Ocupacion.BAJO, 350);
        agregarEstacionATroncal(caracas, "Fucha", Ocupacion.MEDIO, 380);
        agregarEstacionATroncal(caracas, "Hospital", Ocupacion.ALTO, 420);
        agregarEstacionATroncal(caracas, "Tercer Milenio", Ocupacion.MEDIO, 450);
        sistema.agregarTroncal(caracas);
        
        // ===== 5. TRONCAL NQS (E/G) =====
        Troncal nqs = new Troncal("E", "NQS", 470);
        agregarEstacionATroncal(nqs, "Portal Sur", Ocupacion.ALTO, 0);
        agregarEstacionATroncal(nqs, "Terreros", Ocupacion.MEDIO, 550);
        agregarEstacionATroncal(nqs, "San Mateo", Ocupacion.MEDIO, 480);
        agregarEstacionATroncal(nqs, "Bosa", Ocupacion.ALTO, 500);
        agregarEstacionATroncal(nqs, "Venecia", Ocupacion.MEDIO, 450);
        agregarEstacionATroncal(nqs, "Alquería", Ocupacion.MEDIO, 420);
        agregarEstacionATroncal(nqs, "General Santander", Ocupacion.BAJO, 400);
        agregarEstacionATroncal(nqs, "Comuneros", Ocupacion.MEDIO, 450);
        agregarEstacionATroncal(nqs, "Ricaurte", Ocupacion.ALTO, 480);
        agregarEstacionATroncal(nqs, "Paloquemao", Ocupacion.MEDIO, 420);
        agregarEstacionATroncal(nqs, "CAD", Ocupacion.MEDIO, 400);
        agregarEstacionATroncal(nqs, "Campín", Ocupacion.ALTO, 450);
        agregarEstacionATroncal(nqs, "Universidad Nacional", Ocupacion.MEDIO, 500);
        sistema.agregarTroncal(nqs);
        
        // ===== 6. TRONCAL AMÉRICAS (F) =====
        Troncal americas = new Troncal("F", "Américas", 460);
        agregarEstacionATroncal(americas, "Portal Américas", Ocupacion.ALTO, 0);
        agregarEstacionATroncal(americas, "Biblioteca Tintal", Ocupacion.BAJO, 600);
        agregarEstacionATroncal(americas, "Kennedy", Ocupacion.ALTO, 500);
        agregarEstacionATroncal(americas, "Mandalay", Ocupacion.MEDIO, 450);
        agregarEstacionATroncal(americas, "Banderas", Ocupacion.MEDIO, 420);
        agregarEstacionATroncal(americas, "Marsella", Ocupacion.BAJO, 400);
        agregarEstacionATroncal(americas, "Américas Carrera 53A", Ocupacion.MEDIO, 450);
        agregarEstacionATroncal(americas, "Puente Aranda", Ocupacion.ALTO, 480);
        agregarEstacionATroncal(americas, "CDS Carrera 32", Ocupacion.MEDIO, 420);
        sistema.agregarTroncal(americas);
        
        // ===== 7. TRONCAL CALLE 26 (K) =====
        Troncal calle26 = new Troncal("K", "Calle 26", 530);
        agregarEstacionATroncal(calle26, "Portal Eldorado", Ocupacion.ALTO, 0);
        agregarEstacionATroncal(calle26, "Modelia", Ocupacion.MEDIO, 550);
        agregarEstacionATroncal(calle26, "Av. Rojas", Ocupacion.MEDIO, 480);
        agregarEstacionATroncal(calle26, "El Tiempo - Maloka", Ocupacion.BAJO, 450);
        agregarEstacionATroncal(calle26, "Salitre - El Greco", Ocupacion.MEDIO, 420);
        agregarEstacionATroncal(calle26, "CAN", Ocupacion.ALTO, 500);
        agregarEstacionATroncal(calle26, "Quinta Paredes", Ocupacion.MEDIO, 400);
        agregarEstacionATroncal(calle26, "Av. Chile", Ocupacion.MEDIO, 450);
        sistema.agregarTroncal(calle26);
        
        // ===== 8. TRONCAL CARRERA 10 (L) =====
        Troncal carrera10 = new Troncal("L", "Carrera 10", 490);
        agregarEstacionATroncal(carrera10, "Portal 20 de Julio", Ocupacion.ALTO, 0);
        agregarEstacionATroncal(carrera10, "Country Sur", Ocupacion.MEDIO, 550);
        agregarEstacionATroncal(carrera10, "Av. 1 Mayo", Ocupacion.ALTO, 500);
        agregarEstacionATroncal(carrera10, "Ciudad Jardín", Ocupacion.MEDIO, 480);
        agregarEstacionATroncal(carrera10, "Policarpa", Ocupacion.MEDIO, 450);
        agregarEstacionATroncal(carrera10, "San Victorino", Ocupacion.ALTO, 500);
        agregarEstacionATroncal(carrera10, "Museo Nacional", Ocupacion.MEDIO, 420);
        sistema.agregarTroncal(carrera10);
        
        System.out.println("✓ Troncales cargadas: " + sistema.getTroncales().size());
        System.out.println("✓ Estaciones cargadas: " + sistema.getEstaciones().size());
    }
    
    private void agregarEstacionATroncal(Troncal troncal, String nombre, Ocupacion ocupacion, double distancia) {
        String codigo = generarCodigoEstacion(nombre);
        
        Estacion estacion = sistema.getEstacion(nombre);
        if (estacion == null) {
            estacion = new Estacion(codigo, nombre, ocupacion);
            sistema.agregarEstacion(estacion);
        }
        
        troncal.agregarEstacion(estacion, distancia);
    }
    
    private String generarCodigoEstacion(String nombre) {
        String codigo = nombre.replaceAll(" ", "")
                               .replaceAll("[áéíóú]", "")
                               .replaceAll("-", "")
                               .toUpperCase();
        if (codigo.length() > 8) {
            codigo = codigo.substring(0, 8);
        }
        return codigo;
    }
    
    /**
     * Carga rutas de ejemplo
     */
    public void cargarRutasEjemplo() {
        System.out.println("\n--- Cargando rutas ---");
        
        // Ruta Express Norte
        Ruta rutaNorteExpress = new Ruta("B01", "Norte Express");
        agregarEstacionARuta(rutaNorteExpress, "Terminal");
        agregarEstacionARuta(rutaNorteExpress, "Mazurén");
        agregarEstacionARuta(rutaNorteExpress, "Calle 127");
        agregarEstacionARuta(rutaNorteExpress, "Calle 100");
        agregarEstacionARuta(rutaNorteExpress, "Virrey");
        agregarEstacionARuta(rutaNorteExpress, "Héroes");
        rutaNorteExpress.setTroncalAsociada(sistema.getTroncal("B"));
        sistema.agregarRuta(rutaNorteExpress);
        
        // Ruta Local Norte
        Ruta rutaNorteLocal = new Ruta("B02", "Norte Local");
        String[] norte = {"Terminal", "Calle 187", "Calle 161", "Mazurén", "Calle 146", 
            "Calle 142", "Alcalá", "Prado", "Calle 127", "Pepe Sierra", "Calle 106", 
            "Calle 100", "Virrey", "Calle 85", "Héroes"};
        for (String est : norte) agregarEstacionARuta(rutaNorteLocal, est);
        rutaNorteLocal.setTroncalAsociada(sistema.getTroncal("B"));
        sistema.agregarRuta(rutaNorteLocal);
        
        // Ruta Express Calle 80
        Ruta ruta80Express = new Ruta("D01", "Calle 80 Express");
        agregarEstacionARuta(ruta80Express, "Portal 80");
        agregarEstacionARuta(ruta80Express, "Minuto de Dios");
        agregarEstacionARuta(ruta80Express, "Avenida 68");
        agregarEstacionARuta(ruta80Express, "Escuela Militar");
        agregarEstacionARuta(ruta80Express, "Polo");
        ruta80Express.setTroncalAsociada(sistema.getTroncal("D"));
        sistema.agregarRuta(ruta80Express);
        
        // Ruta Local Calle 80
        Ruta ruta80Local = new Ruta("D02", "Calle 80 Local");
        String[] calle80 = {"Portal 80", "Quirigua", "Minuto de Dios", "Carrera 53",
            "Ferias", "Avenida 68", "Carrera 47", "Escuela Militar", "Polo"};
        for (String est : calle80) agregarEstacionARuta(ruta80Local, est);
        ruta80Local.setTroncalAsociada(sistema.getTroncal("D"));
        sistema.agregarRuta(ruta80Local);
        
        // Ruta Américas
        Ruta rutaAmericas = new Ruta("F01", "Américas Directa");
        String[] americas = {"Portal Américas", "Biblioteca Tintal", "Kennedy", "Mandalay",
            "Banderas", "Marsella", "Américas Carrera 53A", "Puente Aranda", "CDS Carrera 32"};
        for (String est : americas) agregarEstacionARuta(rutaAmericas, est);
        rutaAmericas.setTroncalAsociada(sistema.getTroncal("F"));
        sistema.agregarRuta(rutaAmericas);
        
        // Ruta NQS
        Ruta rutaNQS = new Ruta("E01", "NQS Express");
        String[] nqs = {"Portal Sur", "Bosa", "Venecia", "Ricaurte", "CAD", "Universidad Nacional"};
        for (String est : nqs) agregarEstacionARuta(rutaNQS, est);
        rutaNQS.setTroncalAsociada(sistema.getTroncal("E"));
        sistema.agregarRuta(rutaNQS);
        
        // Ruta Caracas
        Ruta rutaCaracas = new Ruta("A01", "Caracas Express");
        String[] caracas = {"Portal Usme", "Portal Tunal", "Restrepo", "Hospital", "Tercer Milenio"};
        for (String est : caracas) agregarEstacionARuta(rutaCaracas, est);
        rutaCaracas.setTroncalAsociada(sistema.getTroncal("A"));
        sistema.agregarRuta(rutaCaracas);
        
        // Ruta Calle 26
        Ruta ruta26 = new Ruta("K01", "Calle 26 Express");
        String[] calle26 = {"Portal Eldorado", "El Tiempo - Maloka", "CAN", "Av. Chile"};
        for (String est : calle26) agregarEstacionARuta(ruta26, est);
        ruta26.setTroncalAsociada(sistema.getTroncal("K"));
        sistema.agregarRuta(ruta26);
        
        // Ruta Suba Local
        Ruta rutaSubaLoca = new Ruta("C01", "Suba Local");
        String[] suba = {"Portal Suba", "La Campiña", "Transversal 91", "21 Ángeles",
            "Humedal Córdoba", "Niza Calle 127", "Gratamira", "Suba Av. Boyacá", 
            "Suba Calle 100", "Suba Calle 95", "Rionegro", "San Martín"};
        for (String est : suba) agregarEstacionARuta(rutaSubaLoca, est);
        rutaSubaLoca.setTroncalAsociada(sistema.getTroncal("C"));
        sistema.agregarRuta(rutaSubaLoca);
        
        // Ruta Carrera 10
        Ruta rutaCarrera10 = new Ruta("L01", "Carrera 10 Local");
        String[] c10 = {"Portal 20 de Julio", "Country Sur", "Av. 1 Mayo",
            "Ciudad Jardín", "Policarpa", "San Victorino", "Museo Nacional"};
        for (String est : c10) agregarEstacionARuta(rutaCarrera10, est);
        rutaCarrera10.setTroncalAsociada(sistema.getTroncal("L"));
        sistema.agregarRuta(rutaCarrera10);
        
        System.out.println("✓ Rutas cargadas: " + sistema.getRutas().size());
    }
    
    private void agregarEstacionARuta(Ruta ruta, String nombreEstacion) {
        Estacion estacion = sistema.getEstacion(nombreEstacion);
        if (estacion != null) {
            ruta.agregarEstacion(estacion);
        }
    }
    
    public void mostrarResumen() {
        System.out.println("\n" + "═".repeat(60));
        System.out.println("RESUMEN DEL SISTEMA TRANSMILENIO");
        System.out.println("═".repeat(60));
        System.out.println("Troncales: " + sistema.getTroncales().size());
        System.out.println("Estaciones: " + sistema.getEstaciones().size());
        System.out.println("Rutas: " + sistema.getRutas().size());
    }
}
public class MismaEstacionException extends Exception {
    private final String nombreEstacion;
    
    public MismaEstacionException(String nombreEstacion) {
        super("Origen y destino son la misma estación: '" + nombreEstacion + "'.");
        this.nombreEstacion = nombreEstacion;
    }
    
    public String getNombreEstacion() {
        return nombreEstacion;
    }
}
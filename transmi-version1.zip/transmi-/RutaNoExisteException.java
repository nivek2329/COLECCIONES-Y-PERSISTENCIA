public class RutaNoExisteException extends Exception {
    private final String nombreRuta;
    
    public RutaNoExisteException(String nombreRuta) {
        super("La ruta '" + nombreRuta + "' no existe en el sistema.");
        this.nombreRuta = nombreRuta;
    }
    
    public String getNombreRuta() {
        return nombreRuta;
    }
}
/**
 * Clase principal para probar el sistema con todas las estaciones
 * 
 * @author POOB Team
 * @version 2.0
 */
public class Main {
    
    private SistemaTransmilenio sistema;
    private DatosTransmilenio datos;
    
    public Main() {
        sistema = SistemaTransmilenio.getInstance();
        datos = new DatosTransmilenio();
        datos.cargarTodasLasTroncales();
        datos.cargarRutasEjemplo();
        datos.mostrarResumen();
    }
    
    // ==================== SERVICIO 1 ====================
    
    public void probarServicio1(String estacion) {
        System.out.println("\n--- SERVICIO 1: Tiempo de espera ---");
        try {
            int tiempo = sistema.consultarTiempoEspera(estacion);
            System.out.println("Estación: " + estacion);
            System.out.println("Tiempo de espera: " + tiempo + " minutos");
        } catch (EstacionNoExisteException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    
    // ==================== SERVICIO 2 ====================
    
    public void probarServicio2() {
        System.out.println("\n--- SERVICIO 2: Rutas ordenadas ---");
        System.out.println("Rutas: " + sistema.obtenerRutasOrdenadasAlfabeticamente());
    }
    
    // ==================== SERVICIO 4 ====================
    
    public void probarServicio4(String origen, String destino) {
        System.out.println("\n--- SERVICIO 4: Rutas sin transbordo ---");
        System.out.println("Origen: " + origen + " → Destino: " + destino);
        try {
            System.out.println("Rutas directas: " + sistema.obtenerNombresRutasSinTransbordo(origen, destino));
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    
    // ==================== PRUEBAS COMPLETAS ====================
    
    public void ejecutarPruebas() {
        System.out.println("\n" + "█".repeat(70));
        System.out.println("        PRUEBAS DE SERVICIOS - TRANSMILENIO");
        System.out.println("█".repeat(70));
        
        // Servicio 1
        probarServicio1("Portal 80");
        probarServicio1("Terminal");
        probarServicio1("CAD");
        
        // Servicio 2
        probarServicio2();
        
        // Servicio 4
        probarServicio4("Portal 80", "Polo");
        probarServicio4("Terminal", "Héroes");
        probarServicio4("Portal 80", "Biblioteca Tintal");
    }
}
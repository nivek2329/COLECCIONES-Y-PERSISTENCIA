import java.util.ArrayList;
import java.util.List;

/**
 * Representa una estación del sistema Transmilenio.
 * 
 * @author POOB Team
 * @version 1.0
 */
public class Estacion {
    private final String codigo;
    private final String nombre;
    private final Ocupacion ocupacion;
    private final List<Troncal> troncalesDisponibles;
    
    public Estacion(String codigo, String nombre, Ocupacion ocupacion) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.ocupacion = ocupacion;
        this.troncalesDisponibles = new ArrayList<>();
    }
    
    public String getCodigo() {
        return codigo;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public Ocupacion getOcupacion() {
        return ocupacion;
    }
    
    public int getTiempoEspera() {
        return ocupacion.getTiempoEsperaMinutos();
    }
    
    public void agregarTroncal(Troncal troncal) {
        if (!troncalesDisponibles.contains(troncal)) {
            troncalesDisponibles.add(troncal);
        }
    }
    
    public List<Troncal> getTroncalesDisponibles() {
        return new ArrayList<>(troncalesDisponibles);
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Estacion estacion = (Estacion) obj;
        return nombre.equals(estacion.nombre);
    }
    
    @Override
    public int hashCode() {
        return nombre.hashCode();
    }
    
    @Override
    public String toString() {
        return nombre + " [" + codigo + "] - " + ocupacion;
    }
}
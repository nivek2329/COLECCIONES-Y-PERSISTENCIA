import java.util.*;
import java.util.stream.Collectors;

/**
 * Clase principal del sistema Transmilenio (Singleton).
 * 
 * @author POOB Team
 * @version 1.0
 */
public class SistemaTransmilenio {
    private static SistemaTransmilenio instance;
    
    private final Map<String, Troncal> troncales;
    private final Map<String, Estacion> estaciones;
    private final Map<String, Ruta> rutas;
    
    private SistemaTransmilenio() {
        this.troncales = new HashMap<>();
        this.estaciones = new HashMap<>();
        this.rutas = new HashMap<>();
    }
    
    public static synchronized SistemaTransmilenio getInstance() {
        if (instance == null) {
            instance = new SistemaTransmilenio();
        }
        return instance;
    }
    
    // ==================== MÉTODOS DE ADMINISTRACIÓN ====================
    
    public void agregarTroncal(Troncal troncal) {
        if (troncal != null) {
            troncales.put(troncal.getId(), troncal);
        }
    }
    
    public void agregarEstacion(Estacion estacion) {
        if (estacion != null) {
            estaciones.put(estacion.getNombre(), estacion);
        }
    }
    
    public void agregarRuta(Ruta ruta) {
        if (ruta != null) {
            rutas.put(ruta.getId(), ruta);
        }
    }
    
    public Estacion getEstacion(String nombre) {
        return estaciones.get(nombre);
    }
    
    public Ruta getRuta(String id) {
        return rutas.get(id);
    }
    
    public Troncal getTroncal(String id) {
        return troncales.get(id);
    }
    
    public Collection<Troncal> getTroncales() {
        return troncales.values();
    }
    
    public Collection<Estacion> getEstaciones() {
        return estaciones.values();
    }
    
    public Collection<Ruta> getRutas() {
        return rutas.values();
    }
    
    // ==================== SERVICIO 1 ====================
    
    public int consultarTiempoEspera(String nombreEstacion) 
            throws EstacionNoExisteException {
        
        if (nombreEstacion == null || nombreEstacion.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre de la estación no puede ser nulo o vacío");
        }
        
        Estacion estacion = estaciones.get(nombreEstacion);
        
        if (estacion == null) {
            throw new EstacionNoExisteException(nombreEstacion);
        }
        
        return estacion.getTiempoEspera();
    }
    
    // ==================== SERVICIO 2 ====================
    
    public List<String> obtenerRutasOrdenadasAlfabeticamente() {
        if (rutas.isEmpty()) {
            return new ArrayList<>();
        }
        
        return rutas.values().stream()
                .map(Ruta::getNombre)
                .sorted(String::compareToIgnoreCase)
                .collect(Collectors.toList());
    }
    
    // ==================== SERVICIO 4 ====================
    
    public List<Ruta> obtenerRutasSinTransbordo(String nombreEstacionOrigen, String nombreEstacionDestino) 
            throws EstacionNoExisteException, MismaEstacionException {
        
        if (nombreEstacionOrigen == null || nombreEstacionOrigen.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre de la estación origen no puede ser nulo o vacío");
        }
        if (nombreEstacionDestino == null || nombreEstacionDestino.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre de la estación destino no puede ser nulo o vacío");
        }
        
        Estacion origen = estaciones.get(nombreEstacionOrigen);
        Estacion destino = estaciones.get(nombreEstacionDestino);
        
        if (origen == null) {
            throw new EstacionNoExisteException(nombreEstacionOrigen);
        }
        if (destino == null) {
            throw new EstacionNoExisteException(nombreEstacionDestino);
        }
        
        if (origen.equals(destino)) {
            throw new MismaEstacionException(nombreEstacionOrigen);
        }
        
        List<Ruta> rutasValidas = new ArrayList<>();
        
        for (Ruta ruta : rutas.values()) {
            if (ruta.contieneEstacion(origen) && ruta.contieneEstacion(destino)) {
                rutasValidas.add(ruta);
            }
        }
        
        rutasValidas.sort(new Comparator<Ruta>() {
            @Override
            public int compare(Ruta ruta1, Ruta ruta2) {
                try {
                    int paradas1 = ruta1.obtenerNumeroParadas(origen, destino);
                    int paradas2 = ruta2.obtenerNumeroParadas(origen, destino);
                    
                    if (paradas1 != paradas2) {
                        return Integer.compare(paradas1, paradas2);
                    }
                    return ruta1.getNombre().compareToIgnoreCase(ruta2.getNombre());
                } catch (EstacionNoEnRutaException e) {
                    return 0;
                } catch (MismaEstacionException e) {
                    return 0;
                }
            }
        });
        
        return rutasValidas;
    }
    
    public List<String> obtenerNombresRutasSinTransbordo(String origen, String destino) 
            throws EstacionNoExisteException, MismaEstacionException {
        
        List<Ruta> rutas = obtenerRutasSinTransbordo(origen, destino);
        List<String> nombres = new ArrayList<>();
        for (Ruta ruta : rutas) {
            nombres.add(ruta.getNombre());
        }
        return nombres;
    }
}
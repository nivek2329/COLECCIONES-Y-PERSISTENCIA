/**
 * Enumeración que representa los niveles de ocupación de una estación
 * y su correspondiente tiempo de espera en minutos.
 * 
 * @author POOB Team
 * @version 1.0
 */
public enum Ocupacion {
    ALTO(5),      // 5 minutos de espera
    MEDIO(3),     // 3 minutos de espera
    BAJO(1);      // 1 minuto de espera
    
    private final int tiempoEsperaMinutos;
    
    Ocupacion(int tiempoEsperaMinutos) {
        this.tiempoEsperaMinutos = tiempoEsperaMinutos;
    }
    
    public int getTiempoEsperaMinutos() {
        return tiempoEsperaMinutos;
    }
    
    @Override
    public String toString() {
        return name() + " (" + tiempoEsperaMinutos + " min)";
    }
}
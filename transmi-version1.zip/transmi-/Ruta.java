import java.util.ArrayList;
import java.util.List;

/**
 * Representa una ruta de buses del sistema Transmilenio.
 * 
 * @author POOB Team
 * @version 1.0
 */
public class Ruta {
    private final String id;
    private final String nombre;
    private final List<Estacion> estaciones;
    private Troncal troncalAsociada;
    
    public Ruta(String id, String nombre) {
        this.id = id;
        this.nombre = nombre;
        this.estaciones = new ArrayList<>();
    }
    
    public String getId() {
        return id;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public List<Estacion> getEstaciones() {
        return new ArrayList<>(estaciones);
    }
    
    public Troncal getTroncalAsociada() {
        return troncalAsociada;
    }
    
    public void setTroncalAsociada(Troncal troncalAsociada) {
        this.troncalAsociada = troncalAsociada;
    }
    
    public void agregarEstacion(Estacion estacion) {
        estaciones.add(estacion);
    }
    
    public boolean contieneEstacion(Estacion estacion) {
        return estaciones.contains(estacion);
    }
    
    public int obtenerIndiceEstacion(Estacion estacion) {
        return estaciones.indexOf(estacion);
    }
    
    public int obtenerNumeroParadas(Estacion origen, Estacion destino) 
            throws EstacionNoEnRutaException, MismaEstacionException {
        
        if (origen.equals(destino)) {
            throw new MismaEstacionException(origen.getNombre());
        }
        
        int idxOrigen = estaciones.indexOf(origen);
        int idxDestino = estaciones.indexOf(destino);
        
        if (idxOrigen == -1) {
            throw new EstacionNoEnRutaException(origen.getNombre(), nombre);
        }
        if (idxDestino == -1) {
            throw new EstacionNoEnRutaException(destino.getNombre(), nombre);
        }
        
        return Math.abs(idxDestino - idxOrigen);
    }
    
    @Override
    public String toString() {
        return nombre;
    }
}
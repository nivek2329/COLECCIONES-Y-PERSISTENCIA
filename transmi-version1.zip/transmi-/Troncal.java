import java.util.ArrayList;
import java.util.List;

/**
 * Representa una troncal del sistema Transmilenio.
 * 
 * @author POOB Team
 * @version 1.0
 */
public class Troncal {
    private final String id;
    private final String nombre;
    private final int velocidadPromedio;
    private final List<Estacion> estaciones;
    private final List<Double> distanciasTramos;
    
    public Troncal(String id, String nombre, int velocidadPromedio) {
        this.id = id;
        this.nombre = nombre;
        this.velocidadPromedio = velocidadPromedio;
        this.estaciones = new ArrayList<>();
        this.distanciasTramos = new ArrayList<>();
    }
    
    public String getId() {
        return id;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public int getVelocidadPromedio() {
        return velocidadPromedio;
    }
    
    public List<Estacion> getEstaciones() {
        return new ArrayList<>(estaciones);
    }
    
    public void agregarEstacion(Estacion estacion, double distanciaAlAnterior) {
        estaciones.add(estacion);
        distanciasTramos.add(distanciaAlAnterior);
        estacion.agregarTroncal(this);
    }
    
    public double obtenerDistanciaEntre(Estacion origen, Estacion destino) {
        int idxOrigen = estaciones.indexOf(origen);
        int idxDestino = estaciones.indexOf(destino);
        
        if (idxOrigen == -1 || idxDestino == -1) {
            return -1;
        }
        
        int start = Math.min(idxOrigen, idxDestino);
        int end = Math.max(idxOrigen, idxDestino);
        
        double distanciaTotal = 0;
        for (int i = start + 1; i <= end; i++) {
            distanciaTotal += distanciasTramos.get(i);
        }
        return distanciaTotal;
    }
    
    @Override
    public String toString() {
        return nombre + " [" + id + "]";
    }
}
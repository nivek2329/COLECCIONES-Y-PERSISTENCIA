public class EstacionNoEnRutaException extends Exception {
    private final String nombreEstacion;
    private final String nombreRuta;
    
    public EstacionNoEnRutaException(String nombreEstacion, String nombreRuta) {
        super("La estación '" + nombreEstacion + "' no se encuentra en la ruta '" + nombreRuta + "'.");
        this.nombreEstacion = nombreEstacion;
        this.nombreRuta = nombreRuta;
    }
    
    public String getNombreEstacion() {
        return nombreEstacion;
    }
    
    public String getNombreRuta() {
        return nombreRuta;
    }
}